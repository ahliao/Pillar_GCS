#include "./inc/UAVTalk.h"
#include "./inc/TelemetryData.h"
#include <iostream>
#include <fstream>
#include <stdlib.h>
//#include <raspicam/raspicam.h>
#include <ctime>
#include "opencv/highgui.h"
#include "opencv/cv.h"
#include "opencv2/opencv.hpp"
#include <unistd.h>			//Used for UART
#include <fcntl.h>			//Used for UART
#include <termios.h>

//g++ newMain.cpp ./scr/UAVTalk.cpp -I. -I/usr/local/include/ -L/opt/vc/lib -lraspicam -lraspicam_cv -lmmal -lmmal_core -lmmal_util -lopencv_core -lopencv_highgui


using namespace std;
using namespace cv;

int main()
{
	/*raspicam::RaspiCam Camera;
	if(!Camera.open())
	{
		cout << "Error";
	}*/
	
	VideoCapture capture;
	Mat frame;
	capture.open(-1);
	sleep(3);
	TelemetryData data;
	data.uav_rssi = 0;
	data.uav_linkquality = 0;
	data.uav_linkstate = 0;

	data.uav_failsafe = 0;
	data.uav_arm = 0;
	data.uav_flightmode = 0;

	// GPS data
	data.uav_satellites_visible = 0;
	data.uav_fix_type = 0;
	data.uav_gpsheading = 0;
	data.uav_groundspeed = 0;

	// Battery and power data
	data.uav_bat = 0;
	data.uav_current = 0;
	data.uav_amp = 0;

	data.uav_lat = 0;
	data.uav_lon = 0;
	data.uav_alt = 0;

	data.uav_roll = 0;
	data.uav_pitch = 0;
	data.uav_heading = 0;

	// Accelerometer 
	data.uav_accel_x = 0;
	data.uav_accel_y = 0;
	data.uav_accel_z = 0;

	// Gyroscope
	data.uav_gyro_x = 0;
	data.uav_gyro_y = 0;
	data.uav_gyro_z = 0;

	UAVTalk talker;

	int i = 1;
	bool check = true;
	while(i < 600)
	{
		talker.read(data);
		cout << "HEADING: "<<data.uav_heading << endl;
		cout <<  "GPS FIX: "<<(int) data.uav_fix_type << endl;
		string picName = "pic";
		char temp[256] = {0};
		snprintf(temp, 255, "%d", i);
		picName += temp;
		picName += ".jpg";
		cout << picName << endl;
		string tagName = "pic";
		tagName += temp;
		tagName += ".txt";
		cout << tagName << endl;
		cout << "Data Successfully Written" << endl;
		ofstream s;
		s.open(tagName.c_str());
	
		s << data.uav_lat << endl;
		s << data.uav_lon << endl;
		s << data.uav_heading << endl;
		s.close();
		capture >> frame;
		imwrite(picName, frame);
		i++;
		/*unsigned char rx_buffer[256];
		int rx_length = ::read(uart0_filestream, (void*)rx_buffer, 255);
		string gps;		//Filestream, buffer to store in, number of bytes to read (max)
		while (rx_length < 0 || rx_length == 0)
		{
			//printf("waiting? %d\n", rx_length);
			//printf("", rx_buffer);
				//cout << rx_buffer << endl;
			rx_length = ::read(uart0_filestream, (void*)rx_buffer, 255);
			//Waiting to tag
		}
		rx_buffer[rx_length] = '\0';
		cout << rx_buffer << endl;
		gps = reinterpret_cast<const char*>(rx_buffer);
		string lat, latn, lon, lonn;
;		if(!strcmp(gps.substr(0,6).c_str(), "$GPGGA"))
		{
			string picName = "pic";
			char temp[256] = {0};
			snprintf(temp, 255, "%d", i);
			picName += temp;
			picName += ".jpg";
			cout << picName << endl;
			string tagName = "pic";
			tagName += temp;
			tagName += ".txt";
			cout << tagName << endl;
			cout << "Data Successfully Written" << endl;
			int x1, x2, x3, x4, x5;
			x1 = gps.find_first_of(",", 0);
			x2 = gps.find_first_of(",", x1 + 1);
			x3 = gps.find_first_of(",", x2 + 1);
			x4 = gps.find_first_of(",", x3 + 1);
			x5 = gps.find_first_of(",", x4 + 1);
			lat = gps.substr(x2 + 1, x3 - x2);
			lon = gps.substr(x4 + 1, x5 - x4);
			latn = gps.substr(x3 + 1, 1);
			lonn = gps.substr(x5 + 1, 1);
			ofstream s;
			s.open(tagName.c_str());
			cout << s.is_open();
		
			s << lat << " " << latn << endl;
			s << lon << " " << lonn << endl;
			s.close();
			capture >> frame;
			imwrite(picName, frame);
			i++;
		}
		//close(uart0_filestream);
		//Bytes rece
		//s.close();
		
	
//cout << gps << endl;
//cout << rx_buffer << endl;
		/*talker->read(*data);
		s << data->uav_lat << " " << data->uav_lon;
		s.close();
		cout << data->uav_lat << " "
	 << data->uav_lon << " "
	 << data->uav_alt << " "

	 << data->uav_roll << " "
	 << data->uav_pitch << " "
	 << data->uav_heading << " "

	// Accelerometer 
	 << data->uav_accel_x << " "
	 << data->uav_accel_y << " "
	 << data->uav_accel_z << " "

	// Gyroscope
	 << data->uav_gyro_x << " "
	 << data->uav_gyro_y << " "
	 << data->uav_gyro_z  << endl;
		/*Camera.grab();
		unsigned char *data = new unsigned char[Camera.getImageTypeSize(raspicam::RASPICAM_FORMAT_RGB)];
		Camera.retrieve(data, raspicam::RASPICAM_FORMAT_RGB);
		std::ofstream outFile(picName.c_str(), std::ios::binary);
		outFile << "P6\n" << Camera.getWidth() << " " << Camera.getHeight() << " 255\n";
		outFile.write((char*)data, Camera.getImageTypeSize(raspicam::RASPICAM_FORMAT_RGB));
		delete data;
		
		sleep(1);*/
	}
	//close(uart0_filestream);
	 
}
