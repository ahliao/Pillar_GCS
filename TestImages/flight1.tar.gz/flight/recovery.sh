#!/bin/bash

cd /home/pi/Pillar_GCS/flight/RECOVERY
rm pic*
cd /home/pi/Pillar_GCS/flight/
cp pic*.jpg RECOVERY/
cp pic*.txt RECOVERY/
rm pic*

