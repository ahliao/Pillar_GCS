The source code here is built for an ATMEGA328p, the same MCU on an Arduino. 

Some of the source code used is from the Alectryon libraries created by Alex Liao and Clark Zhang.
